from django.apps import AppConfig


class DatlienConfig(AppConfig):
    name = 'datlien'
